# ViralClip AI — free starter

A responsive React/Vite starter for a long-video-to-shorts workflow.

## Run locally
1. Install Node.js 20+.
2. In this folder run `npm install`.
3. Run `npm run dev`.
4. Open the local URL printed by Vite.

## What works in this starter
- Upload a local video file.
- Preview the uploaded video.
- Add a custom time range or generate sample time-based clip suggestions.
- Export a selected range to a centered 9:16 MP4 using FFmpeg.wasm in the browser.

## Important limitations
- "Auto suggestions" are evenly spaced sample ranges, **not AI highlight detection**.
- YouTube URL input is a placeholder: this browser-only demo does not download YouTube videos. Upload a video file you own or have permission to edit.
- FFmpeg.wasm is loaded from a public CDN on first export. Export requires internet access and a modern desktop browser; large videos may exceed device memory.
- The 9:16 output centers the source image with padding; intelligent face tracking, animated captions, transcription, AI scoring, cloud jobs, accounts, and storage are not implemented yet.
- This starter has no paid APIs or backend. Free hosting can serve the frontend, but real AI processing generally needs a backend/model and may have compute limits.

## Suggested next production steps
1. Add a backend job queue and temporary object storage.
2. Add speech-to-text (e.g. a locally hosted Whisper model) and rank segments using transcript/audio signals.
3. Add face detection/reframing and subtitle rendering.
4. Add secure URL ingestion only for sources whose terms and permissions allow it.
5. Add upload limits, cleanup jobs, progress reporting, and abuse protection.
